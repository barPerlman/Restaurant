#include "../include/Table.h"
#include "../include/Restaurant.h"
#include "../include/Dish.h"
#include "../include/Customer.h"
#include <fstream>
#include "../include/Action.h"
using namespace std;

/////////////////////////Restaurant Class functions/////////////////////////////////////

//default empty constructor
Restaurant::Restaurant() : lastId(0), open(false),tables(),menu(),actionsLog() {}


//constructor
Restaurant::Restaurant(const std::string &configFilePath) : lastId(0), open(false),tables(),menu(),actionsLog() {

    std::ifstream file(configFilePath);	//open file to read
    string readLine;			 //holds the current read line from the file
    do {
        std::getline(file, readLine);   //get the current read line from file
        readConfigFile(file, readLine); //go to function that read the parameters out of the file
    } while (!file.eof());   		//read from file till we red all of it
    file.close();  			 //close file
}

//function that read the parameters out of the file
void Restaurant::readConfigFile(ifstream &file, string &readLine) {

    string delimiter = ",";    //use , as delimeter
    size_t pos = 0; 		  //start position for read section
    string token;   		//holds the read section
    //get tables amount
    int tablesAnount; 		  //holds the amount of tables from file
    vector<int> tablesDescription;  //vector of capacities of each table
    //start read file after amount of tables
    while (readLine != "#number of tables\r") {
        getline(file, readLine);
    }
    getline(file, readLine);    //read next line
    tablesAnount = stoi(readLine);
    //send to function which get the capacities parameters of the tables
    readTablesDescription(delimiter, pos, tablesDescription, file, readLine, token);
    getline(file, readLine); //next line
    getline(file, readLine); //next line
    readMenu(file, readLine, delimiter, pos, token);    //call to function which read the menu from file

    //initialization of tables in the restaurant
    for (int i = 0; i < tablesAnount; i++) {
        unsigned int index=i;
        tables.push_back(new Table(tablesDescription.at(index)));
    }
}

//this function initialize the Dishes vector
void Restaurant::readMenu(ifstream &file, string &readLine, const string &delimiter, size_t pos, string &token) {
    int iter = 0; //id of the dish
    while ((pos = readLine.find(delimiter)) != std::string::npos) {
        token = readLine.substr(0, pos);    //split
        string d_name = token;
        readLine.erase(0, d_name.length() + 1);
        token = readLine.substr(0, readLine.find(delimiter));    //split
        DishType d_type = stringToDishType(token);
        readLine.erase(0, token.length() + 1);
        token = readLine.substr(0, readLine.find(delimiter));    //split
        string d_price = token;
        readLine.erase(0, d_price.length());
        Dish dish(iter, d_name, stoi(d_price), d_type);
        //push Dish into vector
        menu.push_back(dish);
        iter++;
        getline(file, readLine);
    }
}

//the following responsible for read the capacities for restaurant tables from file
void Restaurant::readTablesDescription(const string &delimiter, size_t pos, vector<int> &tablesDescription, ifstream &file,
                                  string &readLine, string &token) const {
    getline(file, readLine);    //read next line
    getline(file, readLine);    //read next line


//read and split as long as we are not in the end of the line
    while ((pos = readLine.find(delimiter)) != std::string::npos) {
        token = readLine.substr(0, pos);    //split
        //push capacity into vector
        tablesDescription.push_back(stoi(token));
        readLine.erase(0, pos + delimiter.length());
    }
//push last capacity from file to vector of capacities
    tablesDescription.push_back(stoi(readLine));
}

//this function get eat strategy as string from file and returns its representation as enum
DishType Restaurant::stringToDishType(std::string s_d_type) {
    DishType dishType = VEG;  //this var holds the type to return
    if (s_d_type == "VEG") {
        dishType = VEG;
    } else if (s_d_type == "SPC") {
        dishType = SPC;
    } else if (s_d_type == "BVG") {
        dishType = BVG;
    } else if (s_d_type == "ALC") {
        dishType = ALC;
    }
    return dishType;
}

//this function responsible for the restaurant management
void Restaurant::start() {
    open = true;
    std::cout << "Restaurant is now open!" << std::endl;
    string exeCommand;  //holds the current command to execute received by the user
    do {//get the input command to execute from user in loop
        std::getline(std::cin, exeCommand);
        string delimeter = " ";

        size_t pos = exeCommand.find(delimeter);   //use space as delimeter and take the first word
        string firstWord = exeCommand.substr(0, pos);    //split

        //the command cases:
        if (firstWord == "open") {
            //remove the part which is not relevant anymore of the sentence
            pos = exeCommand.find(delimeter);
            string tableIdStr = exeCommand.substr(0, pos);    //split
            exeCommand.erase(0, pos + delimeter.length());
            openTable(exeCommand);  //call for a function to start the openTable process with command string
        } else if (firstWord == "order") {
            //remove the part which is not relevant anymore of the sentence
            delimeter = " ";
            pos = exeCommand.find(delimeter);
            string tableIdStr = exeCommand.substr(0, pos);    //split
            exeCommand.erase(0, pos + delimeter.length());
            orderFromTable(exeCommand); //call for a function to start the order process with command string
        } else if (firstWord == "move") {
            //remove the part which is not relevant anymore of the sentence
            delimeter = " ";
            pos = exeCommand.find(delimeter);
            string tableIdStr = exeCommand.substr(0, pos);    //split
            exeCommand.erase(0, pos + delimeter.length());
            moveCustomer(exeCommand);
        } else if (firstWord == "close") {
            closeTable(exeCommand);
        } else if (firstWord == "closeall") {
            closeAllTables();
        } else if (firstWord == "menu") {
            printMenu();
        } else if (firstWord == "status") {
            delimeter = " ";
            pos = exeCommand.find(delimeter);
            string tableIdStr = exeCommand.substr(0, pos);    //split
            exeCommand.erase(0, pos + delimeter.length());
            printTableStatus(exeCommand);
        } else if (firstWord == "log") {
            printActionsLog();
        } else if (firstWord == "backup") {
            backupRestaurant();
        } else if (firstWord == "restore") {
            restoreRestaurant();
        }
    } while (exeCommand != "closeall");
   }

//get the amount of tables in restaurant
int Restaurant::getNumOfTables() const {
    return (int) tables.size();
}

//return the table in the required index or nullptr if doesn't exist
Table *Restaurant::getTable(int ind) {

    if (ind >= 0 && ind < getNumOfTables()) {
        return tables[ind];
    }
    return nullptr;
}

// Return a reference to the history of actions
const std::vector<BaseAction *> &Restaurant::getActionsLog() const {
    const vector<BaseAction *> &log = actionsLog; //define a const copy of actions log with read only permission
    return log;
}

//return a ref. to the menu
std::vector<Dish> &Restaurant::getMenu() {
    vector<Dish> &menuCopy = menu;
    return menuCopy;
}

//destructor of restaurant class
Restaurant::~Restaurant() {
    clear();
}

//remove sources of restaurant
void Restaurant::clear() {
    //remove tables vector
    for (Table *table:tables) {
        if(table!=nullptr){
        delete table;
        table = nullptr;}
    }
    tables.clear();
    //remove base actions log
    for (BaseAction *baseAction:actionsLog) {
        if(baseAction!=nullptr){
            delete baseAction;
            baseAction = nullptr;

        }
    }
    actionsLog.clear();
    menu.clear();

}

//copy constructor
Restaurant::Restaurant(const Restaurant &other) : lastId(other.lastId), open(other.open),tables(),menu(other.menu),actionsLog() {


    for (BaseAction *ba:other.actionsLog) {

        actionsLog.push_back(ba->getActionInstance());

    }


    //copy the data into tables
    for (Table *table:other.tables){
        tables.push_back(new Table(*table));
    }


}


//move constructor
Restaurant::Restaurant(Restaurant &&other):lastId(other.lastId),open(other.open),tables(),menu(),actionsLog(){
//use the default move
    menu=std::move(other.menu);
    actionsLog=std::move(other.actionsLog);
    tables=std::move(other.tables);




}

//copy assignment
Restaurant &Restaurant::operator=(const Restaurant &other) {
    if (this != &other) {
        clear();
        //deep copy of actions
        for (BaseAction *ba:other.actionsLog) {
            actionsLog.push_back(ba->getActionInstance());
        }

        //deep copy the data into tables
        for (Table *table:other.tables){
            tables.push_back(new Table(*table));
        }
        //assignment of menu
        for (const Dish &d:other.menu) {
            menu.push_back(d);
        }
        lastId = other.lastId;
        open = other.open;
    }
    return *this;
}

//move assignment
Restaurant &Restaurant::operator=(Restaurant &&other) {
    if (this != &other) {
        clear();
        tables = other.tables;

        //assignment of menu
        menu.clear();
        for (const Dish &d:other.menu) {
            menu.push_back(d);
        }
        actionsLog = other.actionsLog;
        //assign nullptr in vectors values:
        //for tables:
        for (Table *table:other.tables) {
            delete table;
            table = nullptr;
        }
        other.tables.clear();

        //for actions log:
        for (BaseAction *action:other.actionsLog) {
            delete action;
            action = nullptr;
        }
        other.actionsLog.clear();
    }
    return *this;
}

//this function make instance of action that response of opening a table in the restaurant
void Restaurant::openTable(string &exeCommand) {

    //split the execution sentence to its parts:
    string command = exeCommand;  //copy of the command sentence
    string delimeter = " ";
    string secDelimeter=",";
    size_t pos = command.find(delimeter); //position in command sentence
    string tableIdStr = command.substr(0, pos);    //split

    command.erase(0, pos + delimeter.length());


    //read the customers with their strategyType
    string pairNameType;
    string CustomerName;    //name of customer
    string CustomerType;    //type of customer
    //1.read till the pair space
    //2.split them and create instance of customer on heap
    //3.push pointer to instance into vector of pointer
    //send vector of customers and table id to open table constructor
    vector<Customer *> customersList;
    int customerId = lastId;
    while ((pos = command.find(delimeter)) != std::string::npos) {

        pairNameType = command.substr(0, pos);    //get name with type

        command.erase(0, pos + delimeter.length()); //remove red part from sentence
        //separate pair
        pos = pairNameType.find(secDelimeter);  //update last index in strin to read
        CustomerName = pairNameType.substr(0, pos);
        pairNameType.erase(0, pos + 1); //remove red part from pair sentence

        pos = pairNameType.find('\0');    //tells where type ends
        CustomerType = pairNameType.substr(0, pos);    //read type

        //create a customer and push into vector
        buildCustomersPointersVector(CustomerName, customerId, CustomerType, customersList);
        customerId++;   //raise the id of next customer

    }
    //read the last pair from command
    pairNameType = command.substr(0, pos);    //get name with type
    pos = pairNameType.find(secDelimeter);  //update last index in string to read
    CustomerName = pairNameType.substr(0, pos);
    pairNameType.erase(0, pos + 1); //remove red part from pair sentence
    pos = pairNameType.find('\0');    //tells where type ends
    CustomerType = pairNameType.substr(0, pos);    //read type
    //create a customer and push into vector
    buildCustomersPointersVector(CustomerName, customerId, CustomerType, customersList);
    //save the last id for next customer
    lastId = customerId + 1;
    //create instance of the action open table and save it to log
    //if(tables[stoi(tableIdStr)]->isOpen()) {
        BaseAction *open_table = new OpenTable(stoi(tableIdStr), customersList);
        actionsLog.push_back(open_table);   //push action to action log
        //perform open table and send the restaurant as parameter
    open_table->act(*this);

}

//this function make instance of action that response of order from a table in the restaurant
void Restaurant::orderFromTable(string &exeCommand) {
    BaseAction *order_from_table = new Order(stoi(exeCommand));
    actionsLog.push_back(order_from_table);
    order_from_table->act(*this);
}

//this function make instance of action that response of moving a customer from table to table
void Restaurant::moveCustomer(string &exeCommand) {
    int originTable, destTable, customerId;   //those are the initialize fields for the move constructor
    size_t pos;
    string delimeter=" ";
    pos = exeCommand.find(delimeter);   //position of end character of current splitted part
    originTable = stoi(exeCommand.substr(0, pos));  //get the origin table from command and convert to int
    exeCommand.erase(0, pos + 1);
    pos = exeCommand.find(delimeter);   //position of end character of current splitted part
    destTable = stoi(exeCommand.substr(0, pos));
    exeCommand.erase(0, pos + 1);
    customerId = stoi(exeCommand);
    //create action instance type of move customer
    BaseAction *move_customer = new MoveCustomer(originTable, destTable, customerId);
    actionsLog.push_back(move_customer);    //push into actions log
    move_customer->act(*this);  //perform the activation of move customer

}

//this function make instance of action that responsible for close table
void Restaurant::closeTable(string &exeCommand) {


    string delimeter = " ";
    size_t pos = exeCommand.find(delimeter);
    exeCommand.erase(0, pos + delimeter.length());
    pos = exeCommand.find('\r');
    string tableIdStr = exeCommand.substr(0, pos);    //split

    BaseAction *close_table = new Close(stoi(tableIdStr));
    close_table->act(*this);
    actionsLog.push_back(close_table);
    std::cout << close_table->toString() << std::endl;


}

//this function make instance of action that response of close all tables in restaurant
void Restaurant::closeAllTables() {

    BaseAction *close_all = new CloseAll();
    close_all->act(*this);
    open = false; //close restaurant
    clear();
    delete close_all;
}

//this function make instance of action that response of printing the restaurant menu
void Restaurant::printMenu() {
    BaseAction *print_menu = new PrintMenu();
    actionsLog.push_back(print_menu);
    print_menu->act(*this);
}

//this function make instance of action that response of printing table status
void Restaurant::printTableStatus(string &exeCommand) {
    BaseAction *print_table_status = new PrintTableStatus(stoi(exeCommand));
    actionsLog.push_back(print_table_status);
    print_table_status->act(*this);
}

//this function make instance of action that response of displaying the action log
void Restaurant::printActionsLog() {
    BaseAction *log = new PrintActionsLog();
    log->act(*this);
    delete log;
}

//this function make instance of action that response of back up restaurant states
void Restaurant::backupRestaurant() {
    BaseAction *backup = new BackupRestaurant();
    backup->act(*this);
    actionsLog.push_back(backup);

}

//this function make instance of action that response of restoring to last restaurant backup
void Restaurant::restoreRestaurant() {
    BaseAction *restore = new RestoreResturant();
    restore->act(*this);
    actionsLog.push_back(restore);

}

//this function creates and push the suit type of customer into customers list
void Restaurant::buildCustomersPointersVector(string CustomerName, int customerId, string CustomerType,
                                              vector<Customer *> &customersList) {
    
    if (CustomerType == "veg") {
        customersList.push_back(new VegetarianCustomer(CustomerName, customerId));
    } else if (CustomerType == "chp") {
        customersList.push_back(new CheapCustomer(CustomerName, customerId));
    } else if (CustomerType == "spc") {
        customersList.push_back(new SpicyCustomer(CustomerName, customerId));
    } else if (CustomerType == "alc") {
        customersList.push_back(new AlchoholicCustomer(CustomerName, customerId));
    }

}
